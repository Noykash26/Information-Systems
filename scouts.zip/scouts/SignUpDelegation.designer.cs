﻿namespace scouts
{
    partial class Form_SignUpDelegation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lable_SignInDelegation = new System.Windows.Forms.Label();
            this.label_camperBirth = new System.Windows.Forms.Label();
            this.label_camperGender = new System.Windows.Forms.Label();
            this.label_camperPhone = new System.Windows.Forms.Label();
            this.label_email = new System.Windows.Forms.Label();
            this.label_CamperNameHebre = new System.Windows.Forms.Label();
            this.label_CamperNameEnglish = new System.Windows.Forms.Label();
            this.button_cancel = new System.Windows.Forms.Button();
            this.button_register = new System.Windows.Forms.Button();
            this.textBox_ParentName = new System.Windows.Forms.TextBox();
            this.ParentName = new System.Windows.Forms.Label();
            this.Label_ParentPhone = new System.Windows.Forms.Label();
            this.Label_Gender = new System.Windows.Forms.Label();
            this.Label_Phone = new System.Windows.Forms.Label();
            this.Lable = new System.Windows.Forms.Label();
            this.label_DateOfBirth = new System.Windows.Forms.Label();
            this.Label_CamperNameHebrew = new System.Windows.Forms.Label();
            this.Lable_CamperName = new System.Windows.Forms.Label();
            this.showDelName = new System.Windows.Forms.Label();
            this.delEnd = new System.Windows.Forms.Label();
            this.delStart = new System.Windows.Forms.Label();
            this.label_delname = new System.Windows.Forms.Label();
            this.label_end = new System.Windows.Forms.Label();
            this.label_start = new System.Windows.Forms.Label();
            this.textBox_ParentPhone = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Lable_SignInDelegation
            // 
            this.Lable_SignInDelegation.AutoSize = true;
            this.Lable_SignInDelegation.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Lable_SignInDelegation.Location = new System.Drawing.Point(356, 32);
            this.Lable_SignInDelegation.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Lable_SignInDelegation.Name = "Lable_SignInDelegation";
            this.Lable_SignInDelegation.Size = new System.Drawing.Size(367, 36);
            this.Lable_SignInDelegation.TabIndex = 1;
            this.Lable_SignInDelegation.Text = "Register To a Delegation";
            // 
            // label_camperBirth
            // 
            this.label_camperBirth.Location = new System.Drawing.Point(551, 205);
            this.label_camperBirth.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_camperBirth.Name = "label_camperBirth";
            this.label_camperBirth.Size = new System.Drawing.Size(106, 24);
            this.label_camperBirth.TabIndex = 55;
            this.label_camperBirth.Text = "birth";
            // 
            // label_camperGender
            // 
            this.label_camperGender.Location = new System.Drawing.Point(551, 184);
            this.label_camperGender.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_camperGender.Name = "label_camperGender";
            this.label_camperGender.Size = new System.Drawing.Size(106, 24);
            this.label_camperGender.TabIndex = 54;
            this.label_camperGender.Text = "gender";
            // 
            // label_camperPhone
            // 
            this.label_camperPhone.Location = new System.Drawing.Point(551, 162);
            this.label_camperPhone.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_camperPhone.Name = "label_camperPhone";
            this.label_camperPhone.Size = new System.Drawing.Size(106, 24);
            this.label_camperPhone.TabIndex = 53;
            this.label_camperPhone.Text = "phone";
            // 
            // label_email
            // 
            this.label_email.Location = new System.Drawing.Point(551, 137);
            this.label_email.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_email.Name = "label_email";
            this.label_email.Size = new System.Drawing.Size(106, 24);
            this.label_email.TabIndex = 52;
            this.label_email.Text = "email";
            // 
            // label_CamperNameHebre
            // 
            this.label_CamperNameHebre.Location = new System.Drawing.Point(551, 114);
            this.label_CamperNameHebre.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_CamperNameHebre.Name = "label_CamperNameHebre";
            this.label_CamperNameHebre.Size = new System.Drawing.Size(106, 24);
            this.label_CamperNameHebre.TabIndex = 51;
            this.label_CamperNameHebre.Text = "hebName";
            // 
            // label_CamperNameEnglish
            // 
            this.label_CamperNameEnglish.Location = new System.Drawing.Point(551, 88);
            this.label_CamperNameEnglish.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_CamperNameEnglish.Name = "label_CamperNameEnglish";
            this.label_CamperNameEnglish.Size = new System.Drawing.Size(106, 24);
            this.label_CamperNameEnglish.TabIndex = 50;
            this.label_CamperNameEnglish.Text = "engName";
            // 
            // button_cancel
            // 
            this.button_cancel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button_cancel.Location = new System.Drawing.Point(554, 374);
            this.button_cancel.Margin = new System.Windows.Forms.Padding(2);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(79, 34);
            this.button_cancel.TabIndex = 43;
            this.button_cancel.Text = "Cancel";
            this.button_cancel.UseVisualStyleBackColor = false;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click_1);
            // 
            // button_register
            // 
            this.button_register.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button_register.Location = new System.Drawing.Point(453, 374);
            this.button_register.Margin = new System.Windows.Forms.Padding(2);
            this.button_register.Name = "button_register";
            this.button_register.Size = new System.Drawing.Size(79, 34);
            this.button_register.TabIndex = 32;
            this.button_register.Text = "Register";
            this.button_register.UseVisualStyleBackColor = false;
            this.button_register.Click += new System.EventHandler(this.button_register_Click);
            // 
            // textBox_ParentName
            // 
            this.textBox_ParentName.Location = new System.Drawing.Point(512, 231);
            this.textBox_ParentName.Name = "textBox_ParentName";
            this.textBox_ParentName.Size = new System.Drawing.Size(149, 20);
            this.textBox_ParentName.TabIndex = 41;
            // 
            // ParentName
            // 
            this.ParentName.AutoSize = true;
            this.ParentName.Location = new System.Drawing.Point(397, 231);
            this.ParentName.Name = "ParentName";
            this.ParentName.Size = new System.Drawing.Size(66, 13);
            this.ParentName.TabIndex = 40;
            this.ParentName.Text = "ParentName";
            // 
            // Label_ParentPhone
            // 
            this.Label_ParentPhone.AutoSize = true;
            this.Label_ParentPhone.Location = new System.Drawing.Point(397, 254);
            this.Label_ParentPhone.Name = "Label_ParentPhone";
            this.Label_ParentPhone.Size = new System.Drawing.Size(69, 13);
            this.Label_ParentPhone.TabIndex = 39;
            this.Label_ParentPhone.Text = "ParentPhone";
            // 
            // Label_Gender
            // 
            this.Label_Gender.AutoSize = true;
            this.Label_Gender.Location = new System.Drawing.Point(397, 184);
            this.Label_Gender.Name = "Label_Gender";
            this.Label_Gender.Size = new System.Drawing.Size(42, 13);
            this.Label_Gender.TabIndex = 38;
            this.Label_Gender.Text = "Gender";
            // 
            // Label_Phone
            // 
            this.Label_Phone.AutoSize = true;
            this.Label_Phone.Location = new System.Drawing.Point(397, 162);
            this.Label_Phone.Name = "Label_Phone";
            this.Label_Phone.Size = new System.Drawing.Size(38, 13);
            this.Label_Phone.TabIndex = 37;
            this.Label_Phone.Text = "Phone";
            // 
            // Lable
            // 
            this.Lable.AutoSize = true;
            this.Lable.Location = new System.Drawing.Point(397, 137);
            this.Lable.Name = "Lable";
            this.Lable.Size = new System.Drawing.Size(32, 13);
            this.Lable.TabIndex = 36;
            this.Lable.Text = "Email";
            // 
            // label_DateOfBirth
            // 
            this.label_DateOfBirth.AutoSize = true;
            this.label_DateOfBirth.Location = new System.Drawing.Point(397, 210);
            this.label_DateOfBirth.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_DateOfBirth.Name = "label_DateOfBirth";
            this.label_DateOfBirth.Size = new System.Drawing.Size(68, 13);
            this.label_DateOfBirth.TabIndex = 35;
            this.label_DateOfBirth.Text = "Date Of Birth";
            // 
            // Label_CamperNameHebrew
            // 
            this.Label_CamperNameHebrew.AutoSize = true;
            this.Label_CamperNameHebrew.Location = new System.Drawing.Point(397, 111);
            this.Label_CamperNameHebrew.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Label_CamperNameHebrew.Name = "Label_CamperNameHebrew";
            this.Label_CamperNameHebrew.Size = new System.Drawing.Size(114, 13);
            this.Label_CamperNameHebrew.TabIndex = 34;
            this.Label_CamperNameHebrew.Text = "Camper Name Hebrew";
            // 
            // Lable_CamperName
            // 
            this.Lable_CamperName.AutoSize = true;
            this.Lable_CamperName.Location = new System.Drawing.Point(397, 88);
            this.Lable_CamperName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Lable_CamperName.Name = "Lable_CamperName";
            this.Lable_CamperName.Size = new System.Drawing.Size(111, 13);
            this.Lable_CamperName.TabIndex = 33;
            this.Lable_CamperName.Text = "Camper Name English";
            // 
            // showDelName
            // 
            this.showDelName.Location = new System.Drawing.Point(510, 316);
            this.showDelName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.showDelName.Name = "showDelName";
            this.showDelName.Size = new System.Drawing.Size(52, 20);
            this.showDelName.TabIndex = 61;
            this.showDelName.Text = "label4";
            // 
            // delEnd
            // 
            this.delEnd.Location = new System.Drawing.Point(510, 300);
            this.delEnd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.delEnd.Name = "delEnd";
            this.delEnd.Size = new System.Drawing.Size(52, 16);
            this.delEnd.TabIndex = 60;
            this.delEnd.Text = "label5";
            // 
            // delStart
            // 
            this.delStart.Location = new System.Drawing.Point(510, 281);
            this.delStart.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.delStart.Name = "delStart";
            this.delStart.Size = new System.Drawing.Size(80, 20);
            this.delStart.TabIndex = 59;
            this.delStart.Text = "Date Of Birth";
            // 
            // label_delname
            // 
            this.label_delname.AutoSize = true;
            this.label_delname.Location = new System.Drawing.Point(394, 318);
            this.label_delname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_delname.Name = "label_delname";
            this.label_delname.Size = new System.Drawing.Size(85, 13);
            this.label_delname.TabIndex = 58;
            this.label_delname.Text = "Deligation Name";
            // 
            // label_end
            // 
            this.label_end.AutoSize = true;
            this.label_end.Location = new System.Drawing.Point(394, 298);
            this.label_end.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_end.Name = "label_end";
            this.label_end.Size = new System.Drawing.Size(52, 13);
            this.label_end.TabIndex = 57;
            this.label_end.Text = "End Date";
            // 
            // label_start
            // 
            this.label_start.AutoSize = true;
            this.label_start.Location = new System.Drawing.Point(394, 281);
            this.label_start.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_start.Name = "label_start";
            this.label_start.Size = new System.Drawing.Size(55, 13);
            this.label_start.TabIndex = 56;
            this.label_start.Text = "Start Date";
            // 
            // textBox_ParentPhone
            // 
            this.textBox_ParentPhone.Location = new System.Drawing.Point(512, 254);
            this.textBox_ParentPhone.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_ParentPhone.MaxLength = 10;
            this.textBox_ParentPhone.Name = "textBox_ParentPhone";
            this.textBox_ParentPhone.Size = new System.Drawing.Size(149, 20);
            this.textBox_ParentPhone.TabIndex = 62;
            this.textBox_ParentPhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_ParentPhone_KeyPress);
            // 
            // Form_SignUpDelegation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 449);
            this.Controls.Add(this.textBox_ParentPhone);
            this.Controls.Add(this.showDelName);
            this.Controls.Add(this.delEnd);
            this.Controls.Add(this.delStart);
            this.Controls.Add(this.label_delname);
            this.Controls.Add(this.label_end);
            this.Controls.Add(this.label_start);
            this.Controls.Add(this.label_camperBirth);
            this.Controls.Add(this.label_camperGender);
            this.Controls.Add(this.label_camperPhone);
            this.Controls.Add(this.label_email);
            this.Controls.Add(this.label_CamperNameHebre);
            this.Controls.Add(this.label_CamperNameEnglish);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.button_register);
            this.Controls.Add(this.textBox_ParentName);
            this.Controls.Add(this.ParentName);
            this.Controls.Add(this.Label_ParentPhone);
            this.Controls.Add(this.Label_Gender);
            this.Controls.Add(this.Label_Phone);
            this.Controls.Add(this.Lable);
            this.Controls.Add(this.label_DateOfBirth);
            this.Controls.Add(this.Label_CamperNameHebrew);
            this.Controls.Add(this.Lable_CamperName);
            this.Controls.Add(this.Lable_SignInDelegation);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form_SignUpDelegation";
            this.Text = "SignUpDelegation";
            this.Load += new System.EventHandler(this.Form_SignUpDelegation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Lable_SignInDelegation;
        private System.Windows.Forms.Label label_camperBirth;
        private System.Windows.Forms.Label label_camperGender;
        private System.Windows.Forms.Label label_camperPhone;
        private System.Windows.Forms.Label label_email;
        private System.Windows.Forms.Label label_CamperNameHebre;
        private System.Windows.Forms.Label label_CamperNameEnglish;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Button button_register;
        private System.Windows.Forms.TextBox textBox_ParentName;
        private System.Windows.Forms.Label ParentName;
        private System.Windows.Forms.Label Label_ParentPhone;
        private System.Windows.Forms.Label Label_Gender;
        private System.Windows.Forms.Label Label_Phone;
        private System.Windows.Forms.Label Lable;
        private System.Windows.Forms.Label label_DateOfBirth;
        private System.Windows.Forms.Label Label_CamperNameHebrew;
        private System.Windows.Forms.Label Lable_CamperName;
        private System.Windows.Forms.Label showDelName;
        private System.Windows.Forms.Label delEnd;
        private System.Windows.Forms.Label delStart;
        private System.Windows.Forms.Label label_delname;
        private System.Windows.Forms.Label label_end;
        private System.Windows.Forms.Label label_start;
        private System.Windows.Forms.TextBox textBox_ParentPhone;
    }
}