using System;
public interface VR_tour {

}
