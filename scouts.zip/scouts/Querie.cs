using System;
public class Querie {
	public string querie;
	public bool Answer;

	//private Form[] forms;

}
