using System;
public enum Country {
    Nashville,
    Denver,
    Dallas,
    Pennsylvania,
    Seattle,
    plane,
}
//checkd
